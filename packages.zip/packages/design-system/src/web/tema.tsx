import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { ModoTema } from '../base/contratos.ts';

export type TemaEfetivo = 'light' | 'dark';

interface ValorTema {
  readonly modo: ModoTema;
  readonly tema: TemaEfetivo;
  readonly definirModo: (modo: ModoTema) => void;
}

const ContextoTema = createContext<ValorTema | null>(null);

function temaDoSistema(): TemaEfetivo {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return 'light';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

/** Aplica o tema no elemento raiz via data-theme. "system" segue o aparelho. */
export function ThemeProvider({ modoInicial = 'system', children }: { readonly modoInicial?: ModoTema; readonly children: ReactNode }) {
  const [modo, setModo] = useState<ModoTema>(modoInicial);
  const [temaSistema, setTemaSistema] = useState<TemaEfetivo>(temaDoSistema);

  useEffect(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return undefined;
    const consulta = window.matchMedia('(prefers-color-scheme: dark)');
    const aoMudar = () => setTemaSistema(consulta.matches ? 'dark' : 'light');
    consulta.addEventListener('change', aoMudar);
    return () => consulta.removeEventListener('change', aoMudar);
  }, []);

  const tema: TemaEfetivo = modo === 'system' ? temaSistema : modo;

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', tema);
  }, [tema]);

  const valor = useMemo<ValorTema>(() => ({ modo, tema, definirModo: setModo }), [modo, tema]);
  return <ContextoTema.Provider value={valor}>{children}</ContextoTema.Provider>;
}

export function useTema(): ValorTema {
  const valor = useContext(ContextoTema);
  if (valor === null) throw new Error('useTema precisa estar dentro de ThemeProvider');
  return valor;
}
