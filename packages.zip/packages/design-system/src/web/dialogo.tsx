import { useEffect, useRef } from 'react';
import type { DialogoProps } from '../base/contratos.ts';

export function Dialogo({ aberto, titulo, descricao, textoCancelar = 'Cancelar', textoConfirmar, tipoConfirmar, onCancelar, onConfirmar }: DialogoProps) {
  const primeiroBotao = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (!aberto) return undefined;
    primeiroBotao.current?.focus();
    const aoApertarTecla = (evento: KeyboardEvent) => {
      if (evento.key === 'Escape') onCancelar();
    };
    window.addEventListener('keydown', aoApertarTecla);
    return () => window.removeEventListener('keydown', aoApertarTecla);
  }, [aberto, onCancelar]);

  if (!aberto) return null;

  return (
    <div className="mo-dialogo-fundo">
      <div role="dialog" aria-modal="true" aria-labelledby="mo-dialogo-titulo" className="mo-dialogo">
        <h2 id="mo-dialogo-titulo" className="mo-dialogo__titulo">{titulo}</h2>
        <p className="mo-dialogo__descricao">{descricao}</p>
        <div className="mo-dialogo__acoes">
          <button ref={primeiroBotao} type="button" className="mo-botao mo-botao--texto" onClick={onCancelar}>
            {textoCancelar}
          </button>
          <button type="button" className={`mo-botao mo-botao--${tipoConfirmar === 'destrutivo' ? 'destrutivo' : 'primario'}`} onClick={onConfirmar}>
            {textoConfirmar}
          </button>
        </div>
      </div>
    </div>
  );
}
