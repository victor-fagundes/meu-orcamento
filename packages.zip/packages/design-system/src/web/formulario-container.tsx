import { useEffect } from 'react';
import type { FormularioContainerProps } from '../base/contratos.ts';

/** No web, formulários e edições abrem em painel lateral de 460 px (DECISOES_identidade_visual.md, seção 6). */
export function FormularioContainer({ aberto, titulo, children, textoCancelar = 'Cancelar', textoSalvar, salvarDesabilitado = false, onCancelar, onSalvar }: FormularioContainerProps) {
  useEffect(() => {
    if (!aberto) return undefined;
    const aoApertarTecla = (evento: KeyboardEvent) => {
      if (evento.key === 'Escape') onCancelar();
    };
    window.addEventListener('keydown', aoApertarTecla);
    return () => window.removeEventListener('keydown', aoApertarTecla);
  }, [aberto, onCancelar]);

  if (!aberto) return null;

  return (
    <div className="mo-formulario-fundo">
      <section role="dialog" aria-modal="true" aria-label={titulo} className="mo-formulario">
        <h2 className="mo-dialogo__titulo">{titulo}</h2>
        {children}
        <div className="mo-formulario__acoes">
          <button type="button" className="mo-botao mo-botao--texto" onClick={onCancelar}>{textoCancelar}</button>
          <button type="button" className="mo-botao mo-botao--primario" onClick={onSalvar} disabled={salvarDesabilitado}>{textoSalvar}</button>
        </div>
      </section>
    </div>
  );
}
